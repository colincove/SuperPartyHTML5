var Input = {};

//-------------------------
//Enums
//-------------------------
var InputDir 	= new Enum('DOWN', 'UP');