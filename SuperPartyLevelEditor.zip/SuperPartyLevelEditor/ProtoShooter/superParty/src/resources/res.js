var R = {};
R.drawable = {};
R.audio = {};