var ComponentTypes = new Enum("SCRIPT", "PHYSICS");

var Components = {};

