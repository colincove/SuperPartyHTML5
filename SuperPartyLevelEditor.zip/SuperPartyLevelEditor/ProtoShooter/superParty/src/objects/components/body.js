Components.createBody = function(bodyDef)
{
    var body = {};
    return body;
}