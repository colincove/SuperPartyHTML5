function setupLevel()
{
}