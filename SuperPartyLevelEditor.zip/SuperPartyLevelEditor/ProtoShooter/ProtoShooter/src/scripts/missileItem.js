var addHealth;
function Collected(e)
{
   hero.addHealth(addHealth);
}
