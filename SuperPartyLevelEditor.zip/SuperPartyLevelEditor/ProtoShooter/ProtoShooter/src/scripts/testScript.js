var vx = 0;
var agroTrigger;
function update(data)
{
    gameObject.body.transform.applyForce(vx, 0);
}