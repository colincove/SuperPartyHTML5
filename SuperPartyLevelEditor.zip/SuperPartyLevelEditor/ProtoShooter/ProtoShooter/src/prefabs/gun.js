{
    scripts:{
        
    },
    renderers:[
    ],
    triggers:{
    },
    mappings:{"samusController.footTrigger":"triggers.foot", "stiffTriggerFollow.trigger":"triggers.foot"}
}