SuperPartyHTML5
===============

HTML5 Javascript game engine along with a game. 
